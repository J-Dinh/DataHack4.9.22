# DataHack2022
The official repository for the dataset and starter code for DataHack 2022

Remember to join our discord for updates!
https://discord.gg/yHUGnrZE
